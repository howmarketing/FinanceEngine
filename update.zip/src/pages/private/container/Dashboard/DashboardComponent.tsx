import React from "react";

// Styles
import "./DashboardComponent.scss";

const DashboardComponent: React.FC<any> = () => {
	return (
		<>
			<div className="header-container">
				<h1 className="container-title">Dashboard</h1>
			</div>{" "}
		</>
	);
};

export default DashboardComponent;
