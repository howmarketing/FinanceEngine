export type IPageLayoutData = {
	children?: React.ReactNode;
}
