
export type SignInButton = {
    onClick?: () => void;
    children: React.ReactNode;
};