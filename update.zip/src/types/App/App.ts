import { IPublicClientApplication } from "@azure/msal-browser";

export type IApp = {
    msalInstance: IPublicClientApplication;
}